<?php
/**
*   @package BrainSpotifyPage
*   @subpackage Modules
*   @link http://www.brainleaf.eu
*   @license GNU/GPL
*
*   BRAINLEAF Spotify Page
*   ==================================================================
*   Simple module to show a Spotify artist page inside your Joomla.
*   ==================================================================
*   Author: BRAINLEAF Communication | http://brainleaf.eu | (C) 2016
*   License: GNU/GPL 3
*   Version: 1.5.x
*   Compatibility: Joomla 3.2.x or superior
*   ===================================================================
*/ 
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DIRECTORY_SEPARATOR.'helper.php' );

// Get Parameters from Configuration
/* ========================================== */

$modparams = array();

$modparams['artistSearch'] = $params->get('mod_spotifypage_artist-search');

$modparams['pageView']['showArtistName'] = $params->get('mod_spotifypage_show-artistname');
$modparams['pageView']['showAlbums'] = $params->get('mod_spotifypage_show-albums');
$modparams['pageView']['showFollow'] = $params->get('mod_spotifypage_show-follow');

$modparams['albumView']['showTitle'] = $params->get('mod_spotifypage_album_show-title');
$modparams['albumView']['showPlayOn'] = $params->get('mod_spotifypage_album_show-playonspotify');

$modparams['libs']['css'] = ($params->get('mod_spotifypage_libs_load-css') == 1) ? "modules/mod_brainimagelink/assets/css/mod.spotifypage.css" : false;
$modparams['libs']['fontawes'] = ($params->get('mod_spotifypage_libs_load-fontawes') == 1) ? "//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" : false;



// get the items to display from the helper
$modData = spotifyPage::loadSpotifyPage($modparams);

require( JModuleHelper::getLayoutPath( 'mod_brainimagelink', $params->get('layout', 'default' )));


?>