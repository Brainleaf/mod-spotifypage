<?php

/**
*   @package BrainSpotifyPage
*   @subpackage Modules
*   @link http://www.brainleaf.eu
*   @license GNU/GPL
*
*   BRAINLEAF Spotify Page
*   ==================================================================
*   Simple module to show a Spotify artist page inside your Joomla.
*   ==================================================================
*   Author: BRAINLEAF Communication | http://brainleaf.eu | (C) 2016
*   License: GNU/GPL 3
*   Version: 1.5.x
*   Compatibility: Joomla 3.2.x or superior
*   ===================================================================
*/ 

defined('_JEXEC') or die('Restricted access');
 
class spotifyPage {
		
	private $searchUrl = "https://api.spotify.com/v1/search?";
	private $artistInfos = array();
	private $artistAlbums = array();
	public $moduleData = array();
		
	public function loadSpotifyPage($modparams) {
		$artistSearchName = str_replace(" ", "+", $modparams['artistSearch']);
		$this->getArtistInfos($artistSearchName);
		$this->getArtistAlbums($artistSearchName);
		$this->moduleData['artistInfos'] = $this->artistInfos;
		$this->moduleData['artistAlbums'] = $this->artistAlbums;
		return $this->moduleData;
	}	
		
	private function getArtistInfos($artistName) {
		$artistSearchName = str_replace(" ", "+", $artistName);
		$query = "q=" .$artistSearchName. "&type=artist";
		$json = file_get_contents($this->searchUrl.$query);	
		$infos = json_decode($json,true);
		$this->artistInfo['id'] = $infos['artists']['items'][0]['id'];
		$this->artistInfo['name'] = $infos['artists']['items'][0]['name'];
		$this->artistInfo['page'] = $infos['artists']['items'][0]['external_urls']['spotify'];
		$this->artistInfo['genres'] = $infos['artists']['items'][0]['genres'];
		$this->artistInfo['images'] = $infos['artists']['items'][0]['images'];
		$this->artistInfo['followers'] = $infos['artists']['items'][0]['followers']['total'];
	}	 
		
	private function getArtistAlbums($artistName)	{
		$query = "q=" .$artistSearchName. "&type=album";
		$json = file_get_contents($this->searchUrl.$query);	
		$albums = json_decode($json,true);
		$this->artistAlbums = $albums['artists']['items'];
	}
    
}

?>