<?php
/**
*   @package BrainSpotifyPage
*   @subpackage Modules
*   @link http://www.brainleaf.eu
*   @license GNU/GPL
*
*   BRAINLEAF Spotify Page
*   ==================================================================
*   Simple module to show a Spotify artist page inside your Joomla.
*   ==================================================================
*   Author: BRAINLEAF Communication | http://brainleaf.eu | (C) 2016
*   License: GNU/GPL 3
*   Version: 1.5.x
*   Compatibility: Joomla 3.2.x or superior
*   ===================================================================
*/ 

defined('_JEXEC') or die('Restricted access');

/* Libs & CSS */
/* ================================= */

// Module CSS
if ($modparams['libs']['css'] !== FALSE) {
	JFactory::getDocument()->addStyleSheet($modparams['libs']['css']);
}

// FontAwesome CSS
if ($modparams['libs']['fontawes'] !== FALSE) {
    JFactory::getDocument()->addStyleSheet($modparams['libs']['fontawes']);
}

?>

<div class="brainSpotifyPage">
	<div class="brainSpotifyPage_wrapper">
		
		<div class="brainSpotifyPage_artist-infos">
			<div class="brainSpotifyPage_artist-image">
				<img src="<?php echo $modData->artistInfos->images[0]['url'] ?>" alt="Artist Image">
			</div>
			<div class="brainSpotifyPage_artist-name">
				<h4><?php echo $modData->artistInfos->name; ?></h4>
			</div>
			<div class="brainSpotifyPage_artist-details">
				<div class="spotify-page"></div>
				<div class="spotify-followers"></div>
				<div class="spotify-genres"></div>
			</div>
		</div>
		
		<div class="brainSpotifyPage_artist-albums">
			<?php for($i=0; $i<count( $modData->artistAlbums); $i++): ?>
				<div class="brainSpotifyPage_artist-album">
					<div class="brainSpotifyPage_artist-album-inner">
						<div class="brainSpotifyPage_artist-album-image">
							<img src="<?php echo $modData->artistAlbums[$i]['images'][0]['url'] ?>" alt="Artist Image">
						</div>
					</div>
				</div>
			<?php endfor; ?> 
		</div>
		
	</div>
</div>
